﻿using Microsoft.EntityFrameworkCore;
using ProyectoLNSD_WApp.DAL.Entities;

namespace ProyectoLNSD_WApp.DAL.Data
{
    public partial class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        //Tables
        public virtual DbSet<Rol> Roles { get; set; }
        public virtual DbSet<Usuario> Usuarios { get; set; }
        public virtual DbSet<PersonalAdmin> PersonalAdmins { get; set; }
        public virtual DbSet<Docente> Docentes { get; set; }
        public virtual DbSet<Estudiante> Estudiantes { get; set; }
        public virtual DbSet<Encargado> Encargados { get; set; }
        public virtual DbSet<EstudianteDocente> EstudiantesDocentes { get; set; }
        public virtual DbSet<EncargadoEstudiante> EncargadosEstudiantes { get; set; }
        public virtual DbSet<UsuarioTokenReset> UsuariosTokensReset { get; set; }
        public virtual DbSet<Modulo> Modulos { get; set; }
        public virtual DbSet<RolPermiso> RolesPermisos { get; set; }
        public virtual DbSet<LogAcceso> LogsAcceso { get; set; }
        public virtual DbSet<Institucion> Instituciones { get; set; }
        public virtual DbSet<PeriodoLectivo> PeriodosLectivos { get; set; }
        public virtual DbSet<ContenidoSitio> ContenidosSitio { get; set; }
        public virtual DbSet<AccesoRapido> AccesosRapidos { get; set; }
        public virtual DbSet<AccesoRapidoRol> AccesosRapidosRoles { get; set; }
        public virtual DbSet<Tiquete> Tiquetes { get; set; }
        public virtual DbSet<Grado> Grados { get; set; }
        public virtual DbSet<Seccion> Secciones { get; set; }
        public virtual DbSet<Curso> Cursos { get; set; }
        public virtual DbSet<AreaAcademica> AreasAcademicas { get; set; }
        public virtual DbSet<CursoGrado> CursosGrados { get; set; }
        public virtual DbSet<DocenteCurso> DocentesCursos { get; set; }
        public virtual DbSet<RecursoAcademico> RecursosAcademicos { get; set; }
        public virtual DbSet<Grupo> Grupos { get; set; }
        public virtual DbSet<Matricula> Matriculas { get; set; }
        public virtual DbSet<MatriculaCurso> MatriculasCursos { get; set; }
        public virtual DbSet<MatriculaObservacion> MatriculasObservaciones { get; set; }
        public virtual DbSet<MatriculaHistorial> MatriculasHistorial { get; set; }


        //Tables override mode builder
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Rol>(entity =>
            {
                entity.ToTable("Rol");

                entity.HasKey(e => e.IdRol)
                      .HasName("PK_Rol");

                entity.Property(e => e.IdRol)
                      .HasColumnName("id_rol");

                entity.Property(e => e.Nombre)
                      .HasColumnName("nombre")
                      .HasMaxLength(50)
                      .IsRequired();

                entity.Property(e => e.Descripcion)
                      .HasColumnName("descripcion")
                      .HasMaxLength(250);

                entity.HasIndex(e => e.Nombre)
                      .IsUnique()
                      .HasDatabaseName("UQ_Rol_Nombre");
            });

            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.ToTable("Usuario");

                entity.HasKey(e => e.IdUsuario)
                      .HasName("PK_Usuario");

                entity.Property(e => e.IdUsuario)
                      .HasColumnName("id_usuario");

                entity.Property(e => e.IdRol)
                      .HasColumnName("id_rol");

                entity.Property(e => e.Nombre)
                      .HasColumnName("nombre")
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.Apellido)
                      .HasColumnName("apellido")
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.Correo)
                      .HasColumnName("correo")
                      .HasMaxLength(150)
                      .IsRequired();

                entity.Property(e => e.PasswordHash)
                      .HasColumnName("password_hash")
                      .HasColumnType("varbinary(256)")
                      .IsRequired();

                entity.Property(e => e.Estado)
                      .HasColumnName("estado")
                      .HasDefaultValue(true);

                entity.HasIndex(e => e.Correo)
                      .IsUnique()
                      .HasDatabaseName("UQ_Usuario_Correo");

                entity.HasIndex(e => e.IdRol)
                      .HasDatabaseName("IX_Usuario_Rol");

                entity.HasOne(d => d.Rol)
                      .WithMany(p => p.Usuarios)
                      .HasForeignKey(d => d.IdRol)
                      .HasConstraintName("FK_Usuario_Rol");
            });

            modelBuilder.Entity<PersonalAdmin>(entity =>
            {
                entity.ToTable("Personal_Admin");

                entity.HasKey(e => e.IdPerAdm);

                entity.Property(e => e.IdPerAdm)
                      .HasColumnName("id_perAdm");

                entity.Property(e => e.IdUsuario)
                      .HasColumnName("id_usuario");

                entity.Property(e => e.Cargo)
                      .HasColumnName("cargo")
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.Departamento)
                      .HasColumnName("departamento")
                      .HasMaxLength(100)
                      .IsRequired();

                entity.HasIndex(e => e.IdUsuario)
                      .IsUnique()
                      .HasDatabaseName("UQ_Personal_Admin_Usuario");

                entity.HasOne(d => d.Usuario)
                      .WithOne(p => p.PersonalAdmin)
                      .HasForeignKey<PersonalAdmin>(d => d.IdUsuario)
                      .HasConstraintName("FK_Personal_Admin_Usuario");
            });

            modelBuilder.Entity<Docente>(entity =>
            {
                entity.ToTable("Docente", t =>
                    t.HasCheckConstraint("CK_Docente_Experiencia", "anios_experiencia >= 0 AND anios_experiencia <= 60"));

                entity.HasKey(e => e.IdDocente);

                entity.Property(e => e.IdDocente)
                      .HasColumnName("id_docente");

                entity.Property(e => e.IdUsuario)
                      .HasColumnName("id_usuario");

                entity.Property(e => e.Nombre)
                      .HasColumnName("nombre")
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.Apellidos)
                      .HasColumnName("apellidos")
                      .HasMaxLength(150)
                      .IsRequired();

                entity.Property(e => e.Identificacion)
                      .HasColumnName("identificacion")
                      .HasMaxLength(30)
                      .IsRequired();

                entity.Property(e => e.Correo)
                      .HasColumnName("correo")
                      .HasMaxLength(150)
                      .IsRequired();

                entity.Property(e => e.Telefono)
                      .HasColumnName("telefono")
                      .HasMaxLength(30);

                entity.Property(e => e.Direccion)
                      .HasColumnName("direccion")
                      .HasMaxLength(300);

                entity.Property(e => e.Estado)
                      .HasColumnName("estado")
                      .HasDefaultValue(true);

                entity.Property(e => e.Titulos)
                      .HasColumnName("titulos")
                      .HasMaxLength(1000);

                entity.Property(e => e.Especialidad)
                      .HasColumnName("especialidad")
                      .HasMaxLength(150);

                entity.Property(e => e.AniosExperiencia)
                      .HasColumnName("anios_experiencia");

                entity.Property(e => e.IdArea)
                      .HasColumnName("id_area");

                entity.Property(e => e.FechaRegistro)
                      .HasColumnName("fecha_registro")
                      .HasDefaultValueSql("GETUTCDATE()");

                // La cuenta es opcional.
                entity.HasOne(d => d.Usuario)
                      .WithOne(p => p.Docente)
                      .HasForeignKey<Docente>(d => d.IdUsuario)
                      .HasConstraintName("FK_Docente_Usuario");

                entity.HasIndex(e => e.IdUsuario)
                      .IsUnique()
                      .HasFilter("[id_usuario] IS NOT NULL")
                      .HasDatabaseName("UX_Docente_Usuario");

                entity.HasIndex(e => e.Identificacion)
                      .IsUnique()
                      .HasDatabaseName("UQ_Docente_Identificacion");

                entity.HasIndex(e => e.Correo)
                      .IsUnique()
                      .HasDatabaseName("UQ_Docente_Correo");

                entity.HasOne(d => d.Area)
                      .WithMany()
                      .HasForeignKey(d => d.IdArea)
                      .HasConstraintName("FK_Docente_Area");
            });

            modelBuilder.Entity<Estudiante>(entity =>
            {
                entity.ToTable("Estudiante");

                entity.HasKey(e => e.IdEstudiante);

                entity.Property(e => e.IdEstudiante)
                      .HasColumnName("id_estudiante");

                entity.Property(e => e.IdUsuario)
                      .HasColumnName("id_usuario");

                entity.Property(e => e.Identificacion)
                      .HasColumnName("identificacion")
                      .HasMaxLength(30)
                      .IsRequired();

                entity.Property(e => e.Carnet)
                      .HasColumnName("carnet")
                      .HasMaxLength(20)
                      .IsRequired();

                entity.Property(e => e.FechaNacimiento)
                      .HasColumnName("fecha_nacimiento");

                entity.Property(e => e.FechaIngreso)
                      .HasColumnName("fecha_ingreso");

                entity.Property(e => e.Telefono)
                      .HasColumnName("telefono")
                      .HasMaxLength(30);

                entity.Property(e => e.Direccion)
                      .HasColumnName("direccion")
                      .HasMaxLength(300);

                entity.Property(e => e.CorreoEmergencia)
                      .HasColumnName("correo_emergencia")
                      .HasMaxLength(150);

                entity.Property(e => e.IdGrado)
                      .HasColumnName("id_grado");

                entity.Property(e => e.EstadoAcademico)
                      .HasColumnName("estado_academico")
                      .HasMaxLength(30)
                      .IsRequired();

                entity.Property(e => e.Alergias)
                      .HasColumnName("alergias")
                      .HasMaxLength(500);

                entity.Property(e => e.ObservacionesMedicas)
                      .HasColumnName("observaciones_medicas")
                      .HasMaxLength(1000);

                entity.Property(e => e.AdecuacionesEducativas)
                      .HasColumnName("adecuaciones_educativas")
                      .HasMaxLength(1000);

                entity.Property(e => e.Estado)
                      .HasColumnName("estado");

                entity.HasOne(d => d.Grado)
                      .WithMany()
                      .HasForeignKey(d => d.IdGrado)
                      .HasConstraintName("FK_Estudiante_Grado");

                entity.HasIndex(e => e.Carnet)
                      .IsUnique()
                      .HasDatabaseName("UQ_Estudiante_Carnet");

                entity.HasOne(d => d.Usuario)
                      .WithOne(p => p.Estudiante)
                      .HasForeignKey<Estudiante>(d => d.IdUsuario)
                      .HasConstraintName("FK_Estudiante_Usuario");

                entity.HasIndex(e => e.IdUsuario)
                       .IsUnique()
                       .HasDatabaseName("UQ_Estudiante_Usuario");

                entity.HasIndex(e => e.Identificacion)
                      .IsUnique()
                      .HasDatabaseName("UQ_Estudiante_Identificacion");


            });

            modelBuilder.Entity<Encargado>(entity =>
            {
                entity.ToTable("Encargado");

                entity.HasKey(e => e.IdEncargado);

                entity.Property(e => e.IdEncargado)
                      .HasColumnName("id_encargado");

                entity.Property(e => e.IdUsuario)
                      .HasColumnName("id_usuario");

                entity.Property(e => e.Telefono)
                      .HasColumnName("telefono")
                      .HasMaxLength(30);

                entity.HasOne(d => d.Usuario)
                      .WithOne(p => p.Encargado)
                      .HasForeignKey<Encargado>(d => d.IdUsuario)
                      .HasConstraintName("FK_Encargado_Usuario");

                entity.HasIndex(e => e.IdUsuario)
                      .IsUnique()
                      .HasDatabaseName("UQ_Encargado_Usuario");
            });

            modelBuilder.Entity<EstudianteDocente>(entity =>
            {
                entity.ToTable("Estudiante_Docente");

                entity.HasKey(e => new
                {
                    e.IdEstudiante,
                    e.IdDocente
                })
                .HasName("PK_Estudiante_Docente");

                entity.Property(e => e.IdEstudiante)
                      .HasColumnName("id_estudiante");

                entity.Property(e => e.IdDocente)
                      .HasColumnName("id_docente");

                entity.HasOne(d => d.Estudiante)
                      .WithMany(p => p.EstudiantesDocentes)
                      .HasForeignKey(d => d.IdEstudiante)
                      .HasConstraintName("FK_Estudiante_Docente_Estudiante");

                entity.HasOne(d => d.Docente)
                      .WithMany(p => p.EstudiantesDocentes)
                      .HasForeignKey(d => d.IdDocente)
                      .HasConstraintName("FK_Estudiante_Docente_Docente");
            });

            modelBuilder.Entity<EncargadoEstudiante>(entity =>
            {
                entity.ToTable("Encargado_Estudiante");

                entity.HasKey(e => new
                {
                    e.IdEncargado,
                    e.IdEstudiante
                })
                .HasName("PK_Encargado_Estudiante");

                entity.Property(e => e.IdEncargado)
                      .HasColumnName("id_encargado");

                entity.Property(e => e.IdEstudiante)
                      .HasColumnName("id_estudiante");

                entity.Property(e => e.Parentesco)
                      .HasColumnName("parentesco")
                      .HasMaxLength(50)
                      .IsRequired();

                entity.Property(e => e.EsPrincipal)
                      .HasColumnName("es_principal");

                entity.HasOne(d => d.Encargado)
                      .WithMany(p => p.EncargadosEstudiantes)
                      .HasForeignKey(d => d.IdEncargado);

                entity.HasOne(d => d.Estudiante)
                      .WithMany(p => p.EncargadosEstudiantes)
                      .HasForeignKey(d => d.IdEstudiante);
            });

            modelBuilder.Entity<UsuarioTokenReset>(entity =>
            {
                entity.ToTable("Usuario_Token_Reset");

                entity.HasKey(e => e.IdToken)
                      .HasName("PK_Usuario_Token_Reset");

                entity.Property(e => e.IdToken)
                      .HasColumnName("id_token");

                entity.Property(e => e.IdUsuario)
                      .HasColumnName("id_usuario");

                entity.Property(e => e.TokenHash)
                      .HasColumnName("token_hash")
                      .HasColumnType("varbinary(64)")
                      .IsRequired();

                entity.Property(e => e.FechaCreacion)
                      .HasColumnName("fecha_creacion")
                      .HasDefaultValueSql("GETUTCDATE()");

                entity.Property(e => e.FechaExpiracion)
                      .HasColumnName("fecha_expiracion")
                      .IsRequired();

                entity.Property(e => e.Usado)
                      .HasColumnName("usado")
                      .HasDefaultValue(false);

                entity.HasIndex(e => e.TokenHash)
                      .HasDatabaseName("IX_TokenReset_TokenHash");

                entity.HasIndex(e => e.IdUsuario)
                      .HasDatabaseName("IX_TokenReset_Usuario");

                entity.HasOne(d => d.Usuario)
                      .WithMany()
                      .HasForeignKey(d => d.IdUsuario)
                      .HasConstraintName("FK_TokenReset_Usuario");
            });

            modelBuilder.Entity<Modulo>(entity =>
            {
                entity.ToTable("Modulo");

                entity.HasKey(e => e.IdModulo)
                      .HasName("PK_Modulo");

                entity.Property(e => e.IdModulo)
                      .HasColumnName("id_modulo");

                entity.Property(e => e.Nombre)
                      .HasColumnName("nombre")
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.Descripcion)
                      .HasColumnName("descripcion")
                      .HasMaxLength(250);

                entity.HasIndex(e => e.Nombre)
                      .IsUnique()
                      .HasDatabaseName("UQ_Modulo_Nombre");
            });

            modelBuilder.Entity<RolPermiso>(entity =>
            {
                entity.ToTable("Rol_Permiso");

                entity.HasKey(e => e.IdRolPermiso)
                      .HasName("PK_Rol_Permiso");

                entity.Property(e => e.IdRolPermiso)
                      .HasColumnName("id_rol_permiso");

                entity.Property(e => e.IdRol)
                      .HasColumnName("id_rol");

                entity.Property(e => e.IdModulo)
                      .HasColumnName("id_modulo");

                entity.Property(e => e.PuedeVer)
                      .HasColumnName("puede_ver")
                      .HasDefaultValue(false);

                entity.Property(e => e.PuedeCrear)
                      .HasColumnName("puede_crear")
                      .HasDefaultValue(false);

                entity.Property(e => e.PuedeEditar)
                      .HasColumnName("puede_editar")
                      .HasDefaultValue(false);

                entity.Property(e => e.PuedeEliminar)
                      .HasColumnName("puede_eliminar")
                      .HasDefaultValue(false);

                entity.HasIndex(e => new { e.IdRol, e.IdModulo })
                      .IsUnique()
                      .HasDatabaseName("UQ_Rol_Permiso");

                entity.HasIndex(e => e.IdRol)
                      .HasDatabaseName("IX_RolPermiso_Rol");

                entity.HasOne(d => d.Rol)
                      .WithMany()
                      .HasForeignKey(d => d.IdRol)
                      .HasConstraintName("FK_RolPermiso_Rol");

                entity.HasOne(d => d.Modulo)
                      .WithMany(m => m.RolesPermisos)
                      .HasForeignKey(d => d.IdModulo)
                      .HasConstraintName("FK_RolPermiso_Modulo");
            });

            modelBuilder.Entity<LogAcceso>(entity =>
            {
                entity.ToTable("Log_Acceso");

                entity.HasKey(e => e.IdLog)
                      .HasName("PK_Log_Acceso");

                entity.Property(e => e.IdLog)
                      .HasColumnName("id_log");

                entity.Property(e => e.IdUsuario)
                      .HasColumnName("id_usuario");

                entity.Property(e => e.Correo)
                      .HasColumnName("correo")
                      .HasMaxLength(150)
                      .IsRequired();

                entity.Property(e => e.TipoEvento)
                      .HasColumnName("tipo_evento")
                      .HasMaxLength(20)
                      .IsRequired();

                entity.Property(e => e.Exitoso)
                      .HasColumnName("exitoso");

                entity.Property(e => e.Mensaje)
                      .HasColumnName("mensaje")
                      .HasMaxLength(250);

                entity.Property(e => e.Fecha)
                      .HasColumnName("fecha")
                      .HasDefaultValueSql("GETUTCDATE()");

                entity.HasIndex(e => e.IdUsuario)
                      .HasDatabaseName("IX_LogAcceso_Usuario");

                entity.HasIndex(e => e.Fecha)
                      .HasDatabaseName("IX_LogAcceso_Fecha");

                entity.HasOne(d => d.Usuario)
                      .WithMany()
                      .HasForeignKey(d => d.IdUsuario)
                      .HasConstraintName("FK_LogAcceso_Usuario");
            });
            modelBuilder.Entity<Institucion>(entity =>
            {
                entity.ToTable("Institucion");

                entity.HasKey(e => e.IdInstitucion)
                      .HasName("PK_Institucion");

                entity.Property(e => e.IdInstitucion)
                      .HasColumnName("id_institucion");

                entity.Property(e => e.Nombre)
                      .HasColumnName("nombre")
                      .HasMaxLength(150)
                      .IsRequired();

                entity.Property(e => e.Direccion)
                      .HasColumnName("direccion")
                      .HasMaxLength(250);

                entity.Property(e => e.Telefono)
                      .HasColumnName("telefono")
                      .HasMaxLength(50)
                      .IsRequired();

                entity.Property(e => e.TelefonoSecundario)
                      .HasColumnName("telefono_secundario")
                      .HasMaxLength(50);

                entity.Property(e => e.Correo)
                      .HasColumnName("correo")
                      .HasMaxLength(150)
                      .IsRequired();

                entity.Property(e => e.RutaLogo)
                      .HasColumnName("ruta_logo")
                      .HasMaxLength(250);

                entity.Property(e => e.FechaActualizacion)
                      .HasColumnName("fecha_actualizacion")
                      .HasDefaultValueSql("GETUTCDATE()");
            });

            modelBuilder.Entity<PeriodoLectivo>(entity =>
            {
                entity.ToTable("Periodo_Lectivo");

                entity.HasKey(e => e.IdPeriodo)
                      .HasName("PK_Periodo_Lectivo");

                entity.Property(e => e.IdPeriodo)
                      .HasColumnName("id_periodo");

                entity.Property(e => e.Nombre)
                      .HasColumnName("nombre")
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.FechaInicio)
                      .HasColumnName("fecha_inicio");

                entity.Property(e => e.FechaFin)
                      .HasColumnName("fecha_fin");

                entity.Property(e => e.Activo)
                      .HasColumnName("activo");

                entity.HasIndex(e => e.Nombre)
                      .IsUnique()
                      .HasDatabaseName("UQ_Periodo_Nombre");

                entity.HasIndex(e => e.Activo)
                      .IsUnique().HasFilter("[activo] = 1")
                      .HasDatabaseName("UQ_Periodo_Activo");
            });

            modelBuilder.Entity<ContenidoSitio>(entity =>
            {
                entity.ToTable("Contenido_Sitio");

                entity.HasKey(e => e.IdContenido)
                      .HasName("PK_Contenido_Sitio");

                entity.Property(e => e.IdContenido)
                      .HasColumnName("id_contenido");

                entity.Property(e => e.Tipo)
                      .HasColumnName("tipo")
                      .HasMaxLength(30)
                      .IsRequired();

                entity.Property(e => e.Titulo)
                      .HasColumnName("titulo")
                      .HasMaxLength(150)
                      .IsRequired();

                entity.Property(e => e.Descripcion)
                      .HasColumnName("descripcion");

                entity.Property(e => e.RutaImagen)
                      .HasColumnName("ruta_imagen")
                      .HasMaxLength(250);

                entity.Property(e => e.Orden)
                      .HasColumnName("orden");

                entity.Property(e => e.Estado)
                      .HasColumnName("estado")
                      .HasMaxLength(20)
                      .IsRequired();

                entity.Property(e => e.FechaPublicacion)
                      .HasColumnName("fecha_publicacion");

                entity.Property(e => e.FechaActualizacion)
                      .HasColumnName("fecha_actualizacion")
                      .HasDefaultValueSql("GETUTCDATE()");

                entity.Property(e => e.IdUsuarioModifica)
                      .HasColumnName("id_usuario_modifica");
            });

            modelBuilder.Entity<AccesoRapidoRol>(entity =>
            {
                entity.ToTable("Acceso_Rapido_Rol");

                entity.HasKey(e => new { e.IdAcceso, e.IdRol })
                      .HasName("PK_Acceso_Rapido_Rol");

                entity.Property(e => e.IdAcceso)
                      .HasColumnName("id_acceso");

                entity.Property(e => e.IdRol)
                      .HasColumnName("id_rol");

                entity.HasOne(d => d.Acceso)
                      .WithMany()
                      .HasForeignKey(d => d.IdAcceso)
                      .HasConstraintName("FK_AccesoRol_Acceso")
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(d => d.Rol)
                      .WithMany()
                      .HasForeignKey(d => d.IdRol)
                      .HasConstraintName("FK_AccesoRol_Rol");
            });

            modelBuilder.Entity<AccesoRapido>(entity =>
            {
                entity.ToTable("Acceso_Rapido");

                entity.HasKey(e => e.IdAcceso).HasName("PK_Acceso_Rapido");

                entity.Property(e => e.IdAcceso)
                      .HasColumnName("id_acceso");

                entity.Property(e => e.Nombre)
                      .HasColumnName("nombre")
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.Descripcion)
                      .HasColumnName("descripcion")
                      .HasMaxLength(250);

                entity.Property(e => e.Icono)
                      .HasColumnName("icono")
                      .HasMaxLength(50);

                entity.Property(e => e.Enlace)
                      .HasColumnName("enlace")
                      .HasMaxLength(250)
                      .IsRequired();

                entity.Property(e => e.Orden)
                      .HasColumnName("orden");

                entity.Property(e => e.Activo)
                      .HasColumnName("activo");

                entity.Property(e => e.IdModulo)
                      .HasColumnName("id_modulo");

                entity.HasOne<Modulo>()
                      .WithMany()
                      .HasForeignKey(e => e.IdModulo)
                      .HasConstraintName("FK_Acceso_Modulo");
            });

            modelBuilder.Entity<Tiquete>(entity =>
            {
                entity.ToTable("Tiquete");

                entity.HasKey(e => e.IdTiquete)
                      .HasName("PK_Tiquete");

                entity.Property(e => e.IdTiquete)
                      .HasColumnName("id_tiquete");

                entity.Property(e => e.IdUsuario)
                      .HasColumnName("id_usuario");

                entity.Property(e => e.Codigo)
                      .HasColumnName("codigo")
                      .HasMaxLength(30)
                      .IsRequired();

                entity.Property(e => e.Estado)
                      .HasColumnName("estado")
                      .HasMaxLength(20)
                      .IsRequired();

                entity.Property(e => e.FechaGeneracion)
                      .HasColumnName("fecha_generacion")
                      .HasDefaultValueSql("GETUTCDATE()");

                entity.Property(e => e.FechaUtilizacion)
                      .HasColumnName("fecha_utilizacion");

                entity.Property(e => e.IdUsuarioValidador)
                      .HasColumnName("id_usuario_validador");

                entity.HasIndex(e => e.Codigo)
                      .IsUnique()
                      .HasDatabaseName("UQ_Tiquete_Codigo");

                entity.HasOne(d => d.Usuario)
                      .WithMany()
                      .HasForeignKey(d => d.IdUsuario)
                      .OnDelete(DeleteBehavior.Restrict)
                      .HasConstraintName("FK_Tiquete_Usuario");

                entity.HasOne(d => d.UsuarioValidador)
                      .WithMany()
                      .HasForeignKey(d => d.IdUsuarioValidador)
                      .OnDelete(DeleteBehavior.Restrict)
                      .HasConstraintName("FK_Tiquete_Validador");
            });


            modelBuilder.Entity<Grado>(entity =>
            {
                entity.ToTable("Grado");

                entity.HasKey(e => e.IdGrado)
                      .HasName("PK_Grado");

                entity.Property(e => e.IdGrado)
                      .HasColumnName("id_grado");

                entity.Property(e => e.Codigo)
                      .HasColumnName("codigo")
                      .HasMaxLength(20)
                      .IsRequired();

                entity.Property(e => e.Nombre)
                      .HasColumnName("nombre")
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.Nivel)
                      .HasColumnName("nivel")
                      .HasMaxLength(50)
                      .IsRequired();

                entity.Property(e => e.Estado)
                      .HasColumnName("estado");

                entity.HasIndex(e => e.Codigo)
                      .IsUnique()
                      .HasDatabaseName("UQ_Grado_Codigo");

                entity.HasIndex(e => e.Nombre)
                      .IsUnique()
                      .HasDatabaseName("UQ_Grado_Nombre");
            });

            modelBuilder.Entity<Seccion>(entity =>
            {
                entity.ToTable("Seccion");

                entity.HasKey(e => e.IdSeccion)
                      .HasName("PK_Seccion");

                entity.Property(e => e.IdSeccion)
                      .HasColumnName("id_seccion");

                entity.Property(e => e.IdGrado)
                      .HasColumnName("id_grado");

                entity.Property(e => e.Nombre)
                      .HasColumnName("nombre")
                      .HasMaxLength(50)
                      .IsRequired();

                entity.Property(e => e.CapacidadMaxima)
                      .HasColumnName("capacidad_maxima");

                entity.Property(e => e.Estado)
                      .HasColumnName("estado")
                      .HasDefaultValue(true);

                entity.HasIndex(e => new { e.IdGrado, e.Nombre })
                      .IsUnique()
                      .HasDatabaseName("UQ_Seccion_Grado_Nombre");

                entity.HasOne(d => d.Grado)
                      .WithMany(p => p.Secciones)
                      .HasForeignKey(d => d.IdGrado)
                      .HasConstraintName("FK_Seccion_Grado");
            });
            modelBuilder.Entity<Curso>(entity =>
            {
                entity.ToTable("Curso");

                entity.HasKey(e => e.IdCurso)
                      .HasName("PK_Curso");

                entity.Property(e => e.IdCurso)
                      .HasColumnName("id_curso");

                entity.Property(e => e.Codigo)
                      .HasColumnName("codigo")
                      .HasMaxLength(30)
                      .IsRequired();

                entity.Property(e => e.Nombre)
                      .HasColumnName("nombre")
                      .HasMaxLength(150)
                      .IsRequired();

                entity.Property(e => e.Descripcion)
                      .HasColumnName("descripcion")
                      .HasMaxLength(500)
                      .IsRequired();

                entity.Property(e => e.IdArea)
                      .HasColumnName("id_area")
                      .IsRequired();

                entity.Property(e => e.Estado)
                      .HasColumnName("estado")
                      .HasDefaultValue(true);

                entity.HasIndex(e => e.Codigo)
                      .IsUnique()
                      .HasDatabaseName("UQ_Curso_Codigo");

                entity.HasOne(e => e.Area)
                      .WithMany(a => a.Cursos)
                      .HasForeignKey(e => e.IdArea)
                      .OnDelete(DeleteBehavior.Restrict)
                      .HasConstraintName("FK_Curso_Area");
            });

            modelBuilder.Entity<AreaAcademica>(entity =>
            {
                entity.ToTable("Area_Academica");

                entity.HasKey(e => e.IdArea)
                      .HasName("PK_Area_Academica");

                entity.Property(e => e.IdArea)
                      .HasColumnName("id_area");

                entity.Property(e => e.Nombre)
                      .HasColumnName("nombre")
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.Estado)
                      .HasColumnName("estado")
                      .HasDefaultValue(true);

                entity.HasIndex(e => e.Nombre)
                      .IsUnique()
                      .HasDatabaseName("UQ_Area_Academica_Nombre");
            });

            modelBuilder.Entity<CursoGrado>(entity =>
            {
                entity.ToTable("Curso_Grado");

                entity.HasKey(e => new
                {
                    e.IdCurso,
                    e.IdGrado
                })
                .HasName("PK_Curso_Grado");

                entity.Property(e => e.IdCurso)
                      .HasColumnName("id_curso");

                entity.Property(e => e.IdGrado)
                      .HasColumnName("id_grado");

                entity.HasOne(e => e.Curso)
                      .WithMany(c => c.CursosGrados)
                      .HasForeignKey(e => e.IdCurso)
                      .OnDelete(DeleteBehavior.Cascade)
                      .HasConstraintName("FK_Curso_Grado_Curso");

                entity.HasOne(e => e.Grado)
                      .WithMany()
                      .HasForeignKey(e => e.IdGrado)
                      .OnDelete(DeleteBehavior.Restrict)
                      .HasConstraintName("FK_Curso_Grado_Grado");
            });

            modelBuilder.Entity<DocenteCurso>(entity =>
            {
                entity.ToTable("Docente_Curso");

                entity.HasKey(e => e.IdDocenteCurso)
                      .HasName("PK_Docente_Curso");

                entity.Property(e => e.IdDocenteCurso)
                      .HasColumnName("id_docente_curso");

                entity.Property(e => e.IdDocente)
                      .HasColumnName("id_docente");

                entity.Property(e => e.IdCurso)
                      .HasColumnName("id_curso");

                entity.Property(e => e.IdPeriodo)
                      .HasColumnName("id_periodo");

                entity.Property(e => e.FechaAsignacion)
                      .HasColumnName("fecha_asignacion")
                      .HasDefaultValueSql("GETUTCDATE()");

                entity.HasIndex(e => new { e.IdDocente, e.IdCurso, e.IdPeriodo })
                      .IsUnique()
                      .HasDatabaseName("UQ_Docente_Curso_Periodo");

                entity.HasIndex(e => e.IdCurso)
                      .HasDatabaseName("IX_DocenteCurso_Curso");

                entity.HasIndex(e => e.IdPeriodo)
                      .HasDatabaseName("IX_DocenteCurso_Periodo");

                entity.HasOne(d => d.Docente)
                      .WithMany()
                      .HasForeignKey(d => d.IdDocente)
                      .OnDelete(DeleteBehavior.Restrict)
                      .HasConstraintName("FK_DocenteCurso_Docente");

                entity.HasOne(d => d.Curso)
                      .WithMany()
                      .HasForeignKey(d => d.IdCurso)
                      .OnDelete(DeleteBehavior.Restrict)
                      .HasConstraintName("FK_DocenteCurso_Curso");

                entity.HasOne(d => d.Periodo)
                      .WithMany()
                      .HasForeignKey(d => d.IdPeriodo)
                      .OnDelete(DeleteBehavior.Restrict)
                      .HasConstraintName("FK_DocenteCurso_Periodo");
            });

            modelBuilder.Entity<RecursoAcademico>(entity =>
            {
                entity.ToTable("Recursos_Academicos");

                entity.HasKey(e => e.IdRecurso)
                      .HasName("PK_Recursos_Academicos");

                entity.Property(e => e.IdRecurso)
                      .HasColumnName("id_recurso");

                entity.Property(e => e.IdDocente)
                      .HasColumnName("id_docente");

                entity.Property(e => e.IdCurso)
                      .HasColumnName("id_curso");

                entity.Property(e => e.IdGrado)
                      .HasColumnName("id_grado");

                entity.Property(e => e.Titulo)
                      .HasColumnName("titulo")
                      .HasMaxLength(200)
                      .IsRequired();

                entity.Property(e => e.Descripcion)
                      .HasColumnName("descripcion")
                      .HasMaxLength(500);

                entity.Property(e => e.TipoRecurso)
                      .HasColumnName("tipo_recurso")
                      .HasMaxLength(30)
                      .IsRequired();

                entity.Property(e => e.Modalidad)
                      .HasColumnName("modalidad")
                      .HasMaxLength(10)
                      .IsRequired();

                entity.Property(e => e.NombreArchivoOriginal)
                      .HasColumnName("nombre_archivo_original")
                      .HasMaxLength(260);

                entity.Property(e => e.RutaArchivo)
                      .HasColumnName("ruta_archivo")
                      .HasMaxLength(300);

                entity.Property(e => e.Extension)
                      .HasColumnName("extension")
                      .HasMaxLength(10);

                entity.Property(e => e.TamanoBytes)
                      .HasColumnName("tamano_bytes");

                entity.Property(e => e.HashArchivo)
                      .HasColumnName("hash_archivo")
                      .HasMaxLength(64)
                      .IsFixedLength()
                      .IsUnicode(false);

                entity.Property(e => e.UrlEnlace)
                      .HasColumnName("url_enlace")
                      .HasMaxLength(500);

                entity.Property(e => e.FechaPublicacion)
                      .HasColumnName("fecha_publicacion")
                      .HasDefaultValueSql("GETUTCDATE()");

                entity.Property(e => e.FechaModificacion)
                      .HasColumnName("fecha_modificacion");

                entity.HasOne(d => d.Docente)
                      .WithMany()
                      .HasForeignKey(d => d.IdDocente)
                      .OnDelete(DeleteBehavior.Restrict)
                      .HasConstraintName("FK_Recurso_Docente");

                entity.HasOne(d => d.Curso)
                      .WithMany()
                      .HasForeignKey(d => d.IdCurso)
                      .OnDelete(DeleteBehavior.Restrict)
                      .HasConstraintName("FK_Recurso_Curso");

                entity.HasOne(d => d.Grado)
                      .WithMany()
                      .HasForeignKey(d => d.IdGrado)
                      .OnDelete(DeleteBehavior.Restrict)
                      .HasConstraintName("FK_Recurso_Grado");
            });


            modelBuilder.Entity<Grupo>(entity =>
            {
                entity.ToTable("Grupo");
                entity.HasKey(e => e.IdGrupo).HasName("PK_Grupo");
                entity.Property(e => e.IdGrupo).HasColumnName("id_grupo");
                entity.Property(e => e.Nombre).HasColumnName("nombre").HasMaxLength(50).IsRequired();
                entity.Property(e => e.Nivel).HasColumnName("nivel").HasMaxLength(50).IsRequired();
                entity.Property(e => e.Anio).HasColumnName("anio");
                entity.HasIndex(e => new { e.Nombre, e.Anio }).IsUnique().HasDatabaseName("UQ_Grupo_Nombre_Anio");
            });

            modelBuilder.Entity<Matricula>(entity =>
            {
                entity.ToTable("Matricula");
                entity.HasKey(e => e.IdMatricula).HasName("PK_Matricula");
                entity.Property(e => e.IdMatricula).HasColumnName("id_matricula");
                entity.Property(e => e.IdEstudiante).HasColumnName("id_estudiante");
                entity.Property(e => e.IdPeriodo).HasColumnName("id_periodo");
                entity.Property(e => e.IdGrupo).HasColumnName("id_grupo");
                entity.Property(e => e.IdSeccion).HasColumnName("id_seccion");
                entity.Property(e => e.FechaMatricula).HasColumnName("fecha_matricula").HasDefaultValueSql("CONVERT(DATE, GETDATE())");
                entity.Property(e => e.Estado).HasColumnName("estado").HasMaxLength(20).HasDefaultValue("Activa").IsRequired();
                entity.Property(e => e.Observaciones).HasColumnName("observaciones").HasMaxLength(500);
                entity.HasIndex(e => new { e.IdEstudiante, e.IdPeriodo }).IsUnique().HasFilter("[estado] <> N'Anulada'").HasDatabaseName("UQ_Matricula_Estudiante_Periodo");
                entity.HasIndex(e => new { e.Estado, e.IdPeriodo }).HasDatabaseName("IX_Matricula_Estado_Periodo");
                entity.HasOne(e => e.Estudiante).WithMany().HasForeignKey(e => e.IdEstudiante).HasConstraintName("FK_Matricula_Estudiante");
                entity.HasOne(e => e.PeriodoLectivo).WithMany().HasForeignKey(e => e.IdPeriodo).HasConstraintName("FK_Matricula_Periodo");
                entity.HasOne(e => e.Grupo).WithMany(g => g.Matriculas).HasForeignKey(e => e.IdGrupo).HasConstraintName("FK_Matricula_Grupo");
                entity.HasOne(e => e.Seccion).WithMany().HasForeignKey(e => e.IdSeccion).HasConstraintName("FK_Matricula_Seccion");
            });

            modelBuilder.Entity<MatriculaCurso>(entity =>
            {
                entity.ToTable("Matricula_Curso");
                entity.HasKey(e => new { e.IdMatricula, e.IdCurso }).HasName("PK_Matricula_Curso");
                entity.Property(e => e.IdMatricula).HasColumnName("id_matricula");
                entity.Property(e => e.IdCurso).HasColumnName("id_curso");
                entity.HasOne(e => e.Matricula).WithMany(m => m.MatriculasCursos).HasForeignKey(e => e.IdMatricula).HasConstraintName("FK_MatriculaCurso_Matricula");
                entity.HasOne(e => e.Curso).WithMany().HasForeignKey(e => e.IdCurso).HasConstraintName("FK_MatriculaCurso_Curso");
            });

            modelBuilder.Entity<MatriculaObservacion>(entity =>
            {
                entity.ToTable("Matricula_Observacion");
                entity.HasKey(e => e.IdObservacion).HasName("PK_Matricula_Observacion");
                entity.Property(e => e.IdObservacion).HasColumnName("id_observacion");
                entity.Property(e => e.IdMatricula).HasColumnName("id_matricula");
                entity.Property(e => e.Observacion).HasColumnName("observacion").HasMaxLength(1000).IsRequired();
                entity.Property(e => e.FechaRegistro).HasColumnName("fecha_registro").HasDefaultValueSql("CONVERT(DATE, GETDATE())");
                entity.HasOne(e => e.Matricula).WithMany(m => m.ObservacionesRegistradas).HasForeignKey(e => e.IdMatricula).HasConstraintName("FK_Matricula_Observacion_Matricula");
            });

            modelBuilder.Entity<MatriculaHistorial>(entity =>
            {
                entity.ToTable("Matricula_Historial");
                entity.HasKey(e => e.IdHistorial).HasName("PK_Matricula_Historial");
                entity.Property(e => e.IdHistorial).HasColumnName("id_historial");
                entity.Property(e => e.IdMatricula).HasColumnName("id_matricula");
                entity.Property(e => e.IdUsuario).HasColumnName("id_usuario");
                entity.Property(e => e.TipoCambio).HasColumnName("tipo_cambio").HasMaxLength(30).IsRequired();
                entity.Property(e => e.EstadoAnterior).HasColumnName("estado_anterior").HasMaxLength(20);
                entity.Property(e => e.EstadoNuevo).HasColumnName("estado_nuevo").HasMaxLength(20);
                entity.Property(e => e.GrupoAnterior).HasColumnName("grupo_anterior");
                entity.Property(e => e.GrupoNuevo).HasColumnName("grupo_nuevo");
                entity.Property(e => e.SeccionAnterior).HasColumnName("seccion_anterior");
                entity.Property(e => e.SeccionNueva).HasColumnName("seccion_nueva");
                entity.Property(e => e.Detalle).HasColumnName("detalle").HasMaxLength(1000);
                entity.Property(e => e.FechaCambio).HasColumnName("fecha_cambio").HasColumnType("datetime2(0)").HasDefaultValueSql("SYSDATETIME()");
                entity.HasOne(e => e.Matricula).WithMany(m => m.Historial).HasForeignKey(e => e.IdMatricula).HasConstraintName("FK_Matricula_Historial_Matricula");
                entity.HasOne(e => e.Usuario).WithMany().HasForeignKey(e => e.IdUsuario).HasConstraintName("FK_Matricula_Historial_Usuario");
                entity.HasOne(e => e.GrupoAnteriorNavigation).WithMany().HasForeignKey(e => e.GrupoAnterior).HasConstraintName("FK_Matricula_Historial_GrupoAnterior");
                entity.HasOne(e => e.GrupoNuevoNavigation).WithMany().HasForeignKey(e => e.GrupoNuevo).HasConstraintName("FK_Matricula_Historial_GrupoNuevo");
                entity.HasOne(e => e.SeccionAnteriorNavigation).WithMany().HasForeignKey(e => e.SeccionAnterior).HasConstraintName("FK_Matricula_Historial_SeccionAnterior");
                entity.HasOne(e => e.SeccionNuevaNavigation).WithMany().HasForeignKey(e => e.SeccionNueva).HasConstraintName("FK_Matricula_Historial_SeccionNueva");
            });

            OnModelCreatingPartial(modelBuilder);
        }
        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}